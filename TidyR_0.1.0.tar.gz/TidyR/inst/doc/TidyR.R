## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(fig.width = 7,fig.height = 5,
                      fig.align = "center", message = FALSE,
                      collapse = TRUE, comment = "#>" )

library(TidyR)     
library(janitor)    
library(ggplot2)

## ----eval=FALSE---------------------------------------------------------------
# install.packages('devtools')
# devtools::install_github("erinweadick/TidyR")

## ----eval=FALSE---------------------------------------------------------------
# library(TidyR)

## ----data-prep----------------------------------------------------------------
library(TidyR)

data(raw_data)


head(raw_data)

## -----------------------------------------------------------------------------
tidy_data <- function(data, case = "snake") {

  if (!is.data.frame(data)) {
    stop("Input must be a data frame")
  }

  tidied_data <- data %>%
    na.omit() %>%
    clean_names(case = case)

  class(tidied_data) <- c("tidy_data", class(tidied_data))
  tidied_data
}

tidied_data <- tidy_data(raw_data, case = "snake")

## -----------------------------------------------------------------------------
load_data <- function(data){
  usethis::use_data(data, compress = "xz", overwrite = TRUE)
}

## -----------------------------------------------------------------------------
plot.tidy_data <- function(x, y = NULL, ...) {
  dots <- list(...)
  var_x <- dots$var_x
  var_y <- dots$var_y

  if (is.null(var_x) || is.null(var_y)) {
    stop("Both 'var_x' and 'var_y' must be specified via ...")
  }

  ggplot2::ggplot(x, ggplot2::aes(x = .data[[var_x]], y = .data[[var_y]])) +
    ggplot2::geom_point(color = "steelblue", size = 3, alpha = 0.8) +
    ggplot2::geom_smooth(
      method = "lm", color = "darkred", se = FALSE,
      linetype = "dashed", linewidth = 1
    ) +
    ggplot2::theme_minimal(base_size = 14) +
    ggplot2::theme(
      plot.title = ggplot2::element_text(
        hjust = 0.5, face = "bold",
        color = "darkblue", size = 16
      ),
      panel.grid.major = ggplot2::element_line(
        color = "lightgray",
        linetype = "dotted"
      ),
      panel.grid.minor = ggplot2::element_blank()
    )
}
#Example
plot(tidied_data,var_x = "chlorophyll",var_y = "spad")

